-- =========================================================
-- Base de datos de ejemplo — Tema 2: Acceso a Bases de Datos
-- Relacionales
--
-- Carga con:
--   mysql -u root -p < schema_employees.sql
-- o desde un cliente MySQL ya conectado:
--   SOURCE schema_employees.sql;
-- =========================================================

CREATE DATABASE IF NOT EXISTS employees DEFAULT CHARACTER SET 'utf8mb4';
USE employees;

-- Orden de borrado inverso al de creación, por las claves foráneas
DROP TABLE IF EXISTS salaries;
DROP TABLE IF EXISTS dept_emp;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS departments;

-- ---------- Tablas ----------

CREATE TABLE departments (
    dept_no   CHAR(4)      NOT NULL,
    dept_name VARCHAR(40)  NOT NULL,
    PRIMARY KEY (dept_no),
    UNIQUE KEY (dept_name)
) ENGINE=InnoDB;

CREATE TABLE employees (
    emp_no     INT           NOT NULL AUTO_INCREMENT,
    birth_date DATE          NOT NULL,
    first_name VARCHAR(14)   NOT NULL,
    last_name  VARCHAR(16)   NOT NULL,
    gender     ENUM('M','F') NOT NULL,
    hire_date  DATE          NOT NULL,
    PRIMARY KEY (emp_no)
) ENGINE=InnoDB;

-- Historial de departamento por empleado (to_date = '9999-01-01' = asignación activa)
CREATE TABLE dept_emp (
    emp_no    INT     NOT NULL,
    dept_no   CHAR(4) NOT NULL,
    from_date DATE    NOT NULL,
    to_date   DATE    NOT NULL,
    PRIMARY KEY (emp_no, dept_no, from_date),
    CONSTRAINT fk_dept_emp_emp  FOREIGN KEY (emp_no)  REFERENCES employees (emp_no)    ON DELETE CASCADE,
    CONSTRAINT fk_dept_emp_dept FOREIGN KEY (dept_no) REFERENCES departments (dept_no) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Historial de salario por empleado (misma convención de to_date)
CREATE TABLE salaries (
    emp_no    INT NOT NULL,
    salary    INT NOT NULL,
    from_date DATE NOT NULL,
    to_date   DATE NOT NULL,
    PRIMARY KEY (emp_no, from_date),
    CONSTRAINT fk_salaries_emp FOREIGN KEY (emp_no) REFERENCES employees (emp_no) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Datos de ejemplo ----------

INSERT INTO departments (dept_no, dept_name) VALUES
    ('d001', 'Marketing'),
    ('d002', 'Finanzas'),
    ('d003', 'Desarrollo'),
    ('d004', 'Recursos Humanos');

INSERT INTO employees (emp_no, birth_date, first_name, last_name, gender, hire_date) VALUES
    (10001, '1985-02-10', 'Marta',  'Serrano',  'F', '2015-06-01'),
    (10002, '1990-07-23', 'Jordi',  'Puig',     'M', '2017-03-15'),
    (10003, '1988-11-05', 'Lucía',  'Ferrer',   'F', '2016-09-20'),
    (10004, '1992-01-30', 'Pau',    'Vidal',    'M', '2019-01-10'),
    (10005, '1983-05-17', 'Carla',  'Esteve',   'F', '2014-11-03'),
    (10006, '1995-09-12', 'Álvaro', 'Molina',   'M', '2021-02-01'),
    (10007, '1987-03-28', 'Noa',    'Ribes',    'F', '2018-07-09'),
    (10008, '1991-12-02', 'Bruno',  'Castells', 'M', '2020-05-22');

INSERT INTO dept_emp (emp_no, dept_no, from_date, to_date) VALUES
    (10001, 'd001', '2015-06-01', '9999-01-01'),
    (10002, 'd003', '2017-03-15', '9999-01-01'),
    (10003, 'd002', '2016-09-20', '9999-01-01'),
    (10004, 'd003', '2019-01-10', '9999-01-01'),
    (10005, 'd004', '2014-11-03', '9999-01-01'),
    (10006, 'd003', '2021-02-01', '9999-01-01'),
    (10007, 'd001', '2018-07-09', '9999-01-01'),
    (10008, 'd002', '2020-05-22', '9999-01-01');

INSERT INTO salaries (emp_no, salary, from_date, to_date) VALUES
    (10001, 28000, '2015-06-01', '9999-01-01'),
    (10002, 32000, '2017-03-15', '9999-01-01'),
    (10003, 30500, '2016-09-20', '9999-01-01'),
    (10004, 26000, '2019-01-10', '9999-01-01'),
    (10005, 34000, '2014-11-03', '9999-01-01'),
    (10006, 24000, '2021-02-01', '9999-01-01'),
    (10007, 29500, '2018-07-09', '9999-01-01'),
    (10008, 31000, '2020-05-22', '9999-01-01');

-- ---------- Procedimiento y función almacenada de ejemplo (sección 10 del tema) ----------

DELIMITER $$

CREATE PROCEDURE multiply(IN pFac1 INT, IN pFac2 INT, OUT pProd INT)
BEGIN
    SET pProd := pFac1 * pFac2;
END$$

-- DETERMINISTIC no es matemáticamente exacto aquí (CURDATE() cambia cada día),
-- pero evita el error 1418 en servidores con log_bin_trust_function_creators
-- desactivado, algo muy habitual en instalaciones de MySQL por defecto.
-- Es un truco típico en entornos de aprendizaje; en producción se ajustaría
-- la configuración del servidor en vez de "mentir" sobre el determinismo.
CREATE FUNCTION antiguedad_anios(pEmpNo INT) RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE anios INT;
    SELECT TIMESTAMPDIFF(YEAR, hire_date, CURDATE()) INTO anios
    FROM employees WHERE emp_no = pEmpNo;
    RETURN anios;
END$$

DELIMITER ;
